const tieneEntrada = (objeto)=>{
    return true
}